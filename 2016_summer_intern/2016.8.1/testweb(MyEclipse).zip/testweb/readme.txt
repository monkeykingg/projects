web开发步骤

1. 搭建开发环境

	1.1. 导开发包
		dom4j开发包
		jstl开发包
		beanUtils开发包
		log4j开发包
	
	1.2. 创建组织程序的包
		cn.itcast.domain
		cn.itcast.dao
		cn.itcast.dao.imp1
		cn.itcast.service
		cn.itcast.service.imp1
		cn.itcast.web.controller  (处理请求的servlet)
		cn.itcast.web.UI
		cn.itcast.utils
		junit.test
		
		WEB-INF/jsp  保存网站所有jsp
	
	1.3. 创建代表数据库的xml文件
	
	
2. 