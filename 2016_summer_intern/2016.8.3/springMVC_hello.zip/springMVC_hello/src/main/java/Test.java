import org.springframework.web.servlet.DispatcherServlet;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

public class Test {
	DispatcherServlet ds = null;
	InternalResourceViewResolver irvr= null;
}
