package org.it.springmvc.action;

public class UserController {
	
	public String hello(){
		System.out.println("hello");
	}
}
